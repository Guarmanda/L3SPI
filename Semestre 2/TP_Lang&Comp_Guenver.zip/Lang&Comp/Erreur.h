enum eErreur {eLimite0,eAlex0,eAlexReel,eAlex1,eSem0,eSemHoraire,eSem1,eSynt0,eSyntInstruction,eSynt1,eLimite1};
void ErreurAMORCER();
void ErreurDenoncer();
void ErreurEmpiler(int nErreurNumero, int nLexeme);
int nErreurEnTout();
void ErreurINITIALISER();
void ErreurTESTER(int iTest);
