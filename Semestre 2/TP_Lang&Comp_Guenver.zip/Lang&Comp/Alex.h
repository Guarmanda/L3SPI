void AlexAMORCER();
void AlexDenoncer(int nLexeme);
void AlexINITIALISER();
void AlexTESTER(int iTest);

int bAlexEntier(int iDebut);
int bAlexFinFichier(int iDebut);
int bAlexIdentificateur(int iDebut);
int nAlexInstruction(int iDebut);
int bAlexReel(int iDebut);
int bAlexAnalyser(char *sSource);
int nAlexInstruS(int iDebut);
int bAlexHoraire(int uLexeme);
int bAlexReel(int uLexeme);
int bAlexLexeme(int nLexeme);