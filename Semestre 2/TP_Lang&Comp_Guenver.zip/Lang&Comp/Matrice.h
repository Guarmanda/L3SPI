void MatriceAMORCER();
void MatriceINITIALISER();
void MatriceTESTER(int iTest);
