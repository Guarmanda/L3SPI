void DequeAllouer(int nCardinalMax);//O(nCardinalMax)
void DequeAMORCER();
int nDequeCardinal();//O(1)
int bDequeContient(int sSommeT);//O(1)
int sDequeDefiler();//O(1)
int sDequeDepiler();//O(1)
void DequeEmpiler(int sSommeT);//O(1)
void DequeEnfiler(int sSommeT);//O(1)
void DequeINITIALISER();
int sDequeQueue();//O(1)
void DequeRazer(int nCardinalMax);//O(nCardinalMax)
int sDequeSommet();//O(1)
int sDequeSuivant(int sCourant);//O(1)
void DequeTESTER(int iTest);
int sDequeTete();//O(1)
int bDequeVide();//O(1)
void DequeVoir(char *sMessage);//O(taille de la deque)
