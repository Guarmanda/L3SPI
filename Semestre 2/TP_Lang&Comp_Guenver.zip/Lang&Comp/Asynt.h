
void AsyntAMORCER();
void AsyntINITIALISER();
void AsyntTESTER(int iTest);
int bAsyntAnalyser(int bModeSemantique);
enum eGenerationCode {asSyntaxique, asSemantique, asGenerationCode };
